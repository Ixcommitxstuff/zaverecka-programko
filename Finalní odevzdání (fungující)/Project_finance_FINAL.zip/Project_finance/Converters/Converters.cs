﻿using System;
using System.Globalization;
using Avalonia.Data.Converters;
using Avalonia.Media;
using Project_finance.Models;

namespace Project_finance.Converters;

public class TransactionTypeConverter : IValueConverter
{
    public static readonly TransactionTypeConverter Instance = new();
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is TransactionType t ? (t == TransactionType.Income ? "Příjem" : "Výdaj") : string.Empty;
    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotImplementedException();
}

public class TransactionTypeColorConverter : IValueConverter
{
    public static readonly TransactionTypeColorConverter Instance = new();
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is TransactionType t)
            return t == TransactionType.Income
                ? new SolidColorBrush(Color.Parse("#16A34A"))
                : new SolidColorBrush(Color.Parse("#DC2626"));
        return Brushes.Black;
    }
    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotImplementedException();
}

public class BalanceColorConverter : IValueConverter
{
    public static readonly BalanceColorConverter Instance = new();
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is decimal d)
            return d > 0 ? new SolidColorBrush(Color.Parse("#16A34A"))
                 : d < 0 ? new SolidColorBrush(Color.Parse("#DC2626"))
                 : Brushes.Gray;
        return Brushes.Black;
    }
    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotImplementedException();
}

public class AmountFormatter : IValueConverter
{
    public static readonly AmountFormatter Instance = new();
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is decimal d ? $"{d:N2} Kč" : string.Empty;
    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotImplementedException();
}