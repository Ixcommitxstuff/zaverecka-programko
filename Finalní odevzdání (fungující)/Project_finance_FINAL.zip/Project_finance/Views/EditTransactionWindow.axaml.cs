﻿using System;
using System.Globalization;
using System.Linq;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Project_finance.Models;
using Project_finance.Services;

namespace Project_finance.Views;

public partial class EditTransactionWindow : Window
{
    private readonly DataService _data = App.DataService;
    private readonly CategoryService _categories = App.CategoryService;
    private readonly Transaction _transaction;

    public EditTransactionWindow(Transaction transaction)
    {
        InitializeComponent();
        _transaction = transaction;

        CategoryBox.ItemsSource = _categories.Categories.OrderBy(c => c).ToList();

        // Pre-fill all fields with existing values
        IncomeRadio.IsChecked = transaction.Type == TransactionType.Income;
        ExpenseRadio.IsChecked = transaction.Type == TransactionType.Expense;
        AmountBox.Text = transaction.Amount.ToString("G", CultureInfo.InvariantCulture);
        DescriptionBox.Text = transaction.Description;
        DatePicker.SelectedDate = transaction.Date;

        var cats = _categories.Categories.OrderBy(c => c).ToList();
        CategoryBox.ItemsSource = cats;
        CategoryBox.SelectedItem = cats.FirstOrDefault(c => c == transaction.Category)
                                   ?? cats.FirstOrDefault();
    }

    private void OnSave(object? sender, RoutedEventArgs e)
    {
        ErrorText.IsVisible = false;
        if (!decimal.TryParse(AmountBox.Text?.Replace(',', '.'),
                NumberStyles.Any, CultureInfo.InvariantCulture, out var amount) || amount <= 0)
        {
            ErrorText.Text = "Zadejte platnou kladnou částku.";
            ErrorText.IsVisible = true;
            return;
        }
        if (string.IsNullOrWhiteSpace(DescriptionBox.Text))
        {
            ErrorText.Text = "Popis nesmí být prázdný.";
            ErrorText.IsVisible = true;
            return;
        }

        _transaction.Type = IncomeRadio.IsChecked == true ? TransactionType.Income : TransactionType.Expense;
        _transaction.Amount = amount;
        _transaction.Description = DescriptionBox.Text.Trim();
        _transaction.Category = CategoryBox.SelectedItem as string ?? "Ostatní";
        _transaction.Date = DatePicker.SelectedDate?.DateTime ?? DateTime.Today;

        _data.Save();
        Close();
    }

    private void OnCancel(object? sender, RoutedEventArgs e) => Close();
}