﻿namespace Project_finance.Views;

public class CategoryRow
{
    public string Category { get; set; } = string.Empty;
    public string AmountText { get; set; } = string.Empty;
    public double Percent { get; set; }
}