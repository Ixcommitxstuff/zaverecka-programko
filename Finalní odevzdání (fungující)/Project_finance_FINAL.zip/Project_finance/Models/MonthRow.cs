﻿using Avalonia.Media;

namespace Project_finance.Views;

public class MonthRow
{
    public string MonthLabel { get; set; } = string.Empty;
    public string IncomeText { get; set; } = string.Empty;
    public string ExpenseText { get; set; } = string.Empty;
    public string BalanceText { get; set; } = string.Empty;
    public IBrush BalanceColor { get; set; } = Brushes.Black;
}