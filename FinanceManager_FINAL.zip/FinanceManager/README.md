# Správce osobních financí

Desktopová aplikace pro evidenci příjmů a výdajů, napsaná v **C# + Avalonia UI** (net8.0).

## Požadavky

| Nástroj | Verze |
|---------|-------|
| .NET SDK | 8.0 nebo novější |
| OS | Windows / macOS / Linux |

## Spuštění

```bash
cd FinanceManager
dotnet run
```

## Sestavení (release)

```bash
dotnet publish -c Release -r win-x64 --self-contained
```

---

## Funkce

### Povinné
- ✅ **Přidávání příjmů a výdajů** – formulář s validací vstupů
- ✅ **Kategorie u výdajů** – výběr z uložených kategorií, správa kategorií
- ✅ **Statistiky** – celkové příjmy, výdaje, zůstatek, stav (plus/mínus)
- ✅ **Export přehledu do TXT** – přehledný export s měsíčním rozpisem

### Bonusové
- ✅ **Grafické zobrazení** – sloupcový graf příjmy vs výdaje po měsících
- ✅ **Rozdělení podle měsíců** – tabulka i filtr v hlavním okně
- ✅ **Načtení dat z TXT** – import transakcí z dříve exportovaného souboru
- ✅ **Filtrování podle kategorií** – filtr v hlavním okně
- ✅ **Filtrování podle měsíce** – kombinovatelný s filtrem kategorií

### Technické
- ✅ **AppData ukládání** – `%APPDATA%\FinanceManager\` (Windows) / `~/.config/FinanceManager/`
- ✅ **Validace vstupů** – prázdný popis, záporná/neplatná částka
- ✅ **Minimálně 3 okna** – MainWindow, AddTransactionWindow, StatisticsWindow, ManageCategoriesWindow
- ✅ **Oddělená aplikační logika** – složky `Models/`, `Services/`, `Views/`
- ✅ **Práce s objekty** – třída `Transaction` se serializací/deserializací

---

## Architektura

```
FinanceManager/
├── Models/
│   └── Transaction.cs          # Datový model, serializace do TXT
├── Services/
│   ├── CategoryService.cs      # Načítání a ukládání kategorií (AppData)
│   ├── DataService.cs          # CRUD operace s transakcemi (AppData)
│   └── ExportService.cs        # Export přehledu do TXT
├── Views/
│   ├── MainWindow              # Hlavní přehled, filtry, smazání
│   ├── AddTransactionWindow    # Formulář pro přidání transakce
│   ├── StatisticsWindow        # 3 záložky: přehled, graf, kategorie
│   ├── ManageCategoriesWindow  # Správa kategorií
│   └── MessageBox.cs           # Pomocný dialog
├── Converters/
│   └── Converters.cs           # IValueConverter pro XAML bindings
├── Styles/
│   └── AppStyles.axaml         # Globální styly (card, primary, income…)
├── App.axaml / App.axaml.cs    # Inicializace služeb
└── Program.cs                  # Entry point
```

---

## Datový formát

Transakce jsou uloženy v `transactions.txt` jako řádky pipe-delimited:

```
{Guid}|{Income|Expense}|{Částka}|{Popis}|{Kategorie}|{yyyy-MM-dd}
```

Kategorie jsou uloženy v `categories.txt` (jeden záznam na řádek).

---

## Rozdělení práce (doporučené)

| Student A | Student B |
|-----------|-----------|
| GUI (XAML) – MainWindow, AddTransactionWindow | DataService, CategoryService, ExportService |
| StatisticsWindow, ManageCategoriesWindow | Transaction model, serializace |
| Styles, Converters | ImportFromFile, validace |

---

## GitHub workflow

- Každý týden alespoň 1 smysluplný commit
- Oba členové přispívají do `git log`
- Commit zprávy popisují co bylo přidáno/opraveno

Příklady dobrých zpráv:
```
feat: přidán filtr podle kategorie v MainWindow
fix: opravena validace záporné částky v AddTransactionWindow
feat: sloupcový graf v StatisticsWindow
```
